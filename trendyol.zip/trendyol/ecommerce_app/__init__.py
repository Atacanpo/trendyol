# ecommerce_app/__init__.py
default_app_config = 'ecommerce_app.apps.EcommerceAppConfig'
